# Core phishing detection for all customer touchpoints
core_detector = BankingPhishingDetector(
    bank_name="YourBankName",
    strict_mode=True
)

# Implement at:
# 1. Email gateways
# 2. SMS filtering systems
# 3. Web application firewalls
# 4. Mobile banking apps
# 5. Customer service portals