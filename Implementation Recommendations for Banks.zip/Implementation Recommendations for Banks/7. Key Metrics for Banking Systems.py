BANKING_PHISHING_METRICS = {
    'false_positive_rate': '< 0.1%',  # Critical for customer experience
    'detection_accuracy': '> 99.5%',
    'response_time': '< 100ms',  # For real-time transactions
    'coverage': '100% of customer touchpoints',
    'compliance': '100% regulatory requirements',
    'customer_impact': '< 0.01% false blocks',
    'threat_intelligence_freshness': '< 5 minutes',
    'model_retraining_frequency': 'Daily'
}